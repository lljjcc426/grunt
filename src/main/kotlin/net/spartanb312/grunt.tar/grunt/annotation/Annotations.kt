package net.spartanb312.grunt.annotation

val DISABLE_SCRAMBLE = "Lnet/spartanb312/grunt/annotation/DisableScramble;"
val DISABLE_CONTROLFLOW = "Lnet/spartanb312/grunt/annotation/DisableControlflow;"
val DISABLE_INVOKEDYNAMIC = "Lnet/spartanb312/grunt/annotation/DisableInvokeDynamic;"
val JUNKCALL_EXCLUDED = "Lnet/spartanb312/grunt/annotation/JunkCallExcluded;"