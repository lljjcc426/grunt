package net.spartanb312.grunt.process.transformers.misc

import net.spartanb312.grunt.process.Transformer
import net.spartanb312.grunt.process.resource.ResourceCache

object AntiDebugTransformer : Transformer("AntiDebug", Category.Miscellaneous) {

    override fun ResourceCache.transform() {

    }

}